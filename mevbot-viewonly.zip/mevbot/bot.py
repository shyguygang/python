import asyncio
from web3 import Web3
import telegram
import logging

# Replace with your Ethereum node URL (e.g., Infura)
ETH_NODE_URL = "https://mainnet.infura.io/v3/9b4e315a936e4964b7ac46cce53ad5bf"

# Replace with your Telegram bot token and chat ID
TELEGRAM_BOT_TOKEN = "147e42c9d5ba889829ac864e99d370b6"
TELEGRAM_CHAT_ID = "@tgg0hstBot"

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Web3
w3 = Web3(Web3.HTTPProvider(ETH_NODE_URL))

async def check_ethereum_connection():
    try:
        if w3.is_connected():
            logger.info("Successfully connected to Ethereum node")
            latest_block = w3.eth.get_block('latest')
            logger.info(f"Latest block number: {latest_block['number']}")
        else:
            logger.error("Failed to connect to Ethereum node")
    except Exception as e:
        logger.error(f"Error connecting to Ethereum node: {e}")

async def check_telegram_bot():
    try:
        bot = telegram.Bot(token=TELEGRAM_BOT_TOKEN)
        await bot.send_message(chat_id=TELEGRAM_CHAT_ID, text="Test message from MEV bot")
        logger.info("Successfully sent test message to Telegram")
    except Exception as e:
        logger.error(f"Error with Telegram bot: {e}")

async def monitor_mempool():
    while True:
        try:
            pending_tx_count = len(w3.eth.get_block('pending').transactions)
            logger.info(f"Number of pending transactions: {pending_tx_count}")
            await asyncio.sleep(10)  # Adjust this value based on your needs
        except Exception as e:
            logger.error(f"An error occurred while monitoring mempool: {e}")
            await asyncio.sleep(30)  # Wait longer if an error occurs

async def main():
    await check_ethereum_connection()
    await check_telegram_bot()
    await monitor_mempool()

if __name__ == "__main__":
    asyncio.run(main())